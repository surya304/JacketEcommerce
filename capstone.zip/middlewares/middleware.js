



function checkLogged(req, res, next) {
  console.log('middleware');
  next();
}

